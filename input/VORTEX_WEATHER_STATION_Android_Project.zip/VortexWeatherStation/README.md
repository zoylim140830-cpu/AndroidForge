# VORTEX WEATHER STATION — Android project

Package: `com.vortexweatherstation.app`
Version: 1.0.0
Minimum Android: 8.0 (API 26)
Target SDK: 35

## Included
- Native Kotlin + Jetpack Compose Android application
- Dashboard, calculator, history, settings
- Korean, English (US), Simplified Chinese, Japanese
- Local settings and measurement history using SharedPreferences
- Offline RPM calculation: rotations in 10 seconds × 6
- MPH formula: (RPM × K) + B; K and B must be explicitly configured
- Decimal precision setting (0–4)
- Custom vortex vector launcher artwork

## Build an APK
This is the Android source project, not a precompiled APK. Building requires an Android build environment (Android Studio or a compatible Gradle + Android SDK setup).
1. Open this folder in Android Studio.
2. Allow Gradle sync.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

No network permission or Google Play installation is required by the app itself.

## Important calibration note
The app intentionally does not supply guessed K/B values. Configure coefficients using a valid calibration for your specific anemometer. Until both values are set, the app displays the RPM result and asks for coefficient setup instead of inventing MPH.

## Notes
This is a starter implementation intended for testing and further QA. Verify the build and test the four language modes, coefficient calibration, history deletion, and device layouts before relying on measurements.
