package com.vortexweatherstation.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Navy = Color(0xFF071321)
private val Panel = Color(0xFF102235)
private val Cyan = Color(0xFF22D3EE)
private val Green = Color(0xFF54D69A)
private val White = Color(0xFFF4F8FC)
private val Muted = Color(0xFF9DB0C2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VortexApp(getSharedPreferences("vortex", MODE_PRIVATE)) }
    }
}

data class Reading(val time: Long, val rotations: Int, val rpm: Double, val mph: Double)

private val translations = mapOf(
    "ko" to listOf("대시보드","계산기","기록","설정","최근 관측","풍속","회전 속도","측정 시간","10초 회전수","회전수 입력","계산","지우기","회전수","RPM","MPH","환산 계수가 설정되지 않았습니다. 설정에서 K와 B를 입력하세요.","유효한 숫자를 입력하세요.","측정 기록이 없습니다.","삭제","전체 기록 삭제","언어","한국어","영어 (미국)","중국어 (간체)","일본어","환산 계수","계수 K","계수 B","소수점 자릿수","정보","VORTEX WEATHER STATION","오프라인 계산 지원","계산하려면 K와 B를 설정하세요.","저장","취소","설정 저장 완료","기록을 삭제할까요?","MPH 환산식: (RPM × K) + B","RPM = 10초 회전수 × 6","기록 관리","관측 일시"),
    "en" to listOf("Dashboard","Calculator","History","Settings","Latest observation","Wind speed","Rotational speed","Measurement time","10-second rotation count","Enter rotations","Calculate","Clear","Rotations","RPM","MPH","Conversion coefficients are not set. Enter K and B in Settings.","Enter a valid number.","No measurements yet.","Delete","Delete all history","Language","Korean","English (US)","Chinese (Simplified)","Japanese","Conversion coefficients","Coefficient K","Coefficient B","Decimal precision","About","VORTEX WEATHER STATION","Offline calculations supported","Set K and B to calculate MPH.","Save","Cancel","Settings saved","Delete this record?","MPH formula: (RPM × K) + B","RPM = 10-second rotations × 6","History management","Observation time"),
    "zh" to listOf("仪表板","计算器","历史记录","设置","最近观测","风速","旋转速度","测量时间","10秒旋转次数","输入旋转次数","计算","清除","旋转次数","RPM","MPH","尚未设置换算系数。请在设置中输入 K 和 B。","请输入有效数字。","暂无测量记录。","删除","删除全部记录","语言","韩语","英语（美国）","简体中文","日语","换算系数","系数 K","系数 B","小数位数","关于","VORTEX WEATHER STATION","支持离线计算","请先设置 K 和 B 以计算 MPH。","保存","取消","设置已保存","删除此记录？","MPH 公式：(RPM × K) + B","RPM = 10秒旋转次数 × 6","记录管理","观测时间"),
    "ja" to listOf("ダッシュボード","計算機","履歴","設定","最新の観測","風速","回転速度","測定時刻","10秒間の回転数","回転数を入力","計算","クリア","回転数","RPM","MPH","換算係数が未設定です。設定で K と B を入力してください。","有効な数値を入力してください。","測定記録はありません。","削除","履歴をすべて削除","言語","韓国語","英語（米国）","簡体字中国語","日本語","換算係数","係数 K","係数 B","小数桁数","アプリについて","VORTEX WEATHER STATION","オフライン計算に対応","MPHを計算するにはKとBを設定してください。","保存","キャンセル","設定を保存しました","この記録を削除しますか？","MPHの式：(RPM × K) + B","RPM = 10秒間の回転数 × 6","履歴管理","観測時刻")
)

@Composable
fun VortexApp(prefs: android.content.SharedPreferences) {
    var language by remember { mutableStateOf(prefs.getString("lang", "ko") ?: "ko") }
    var screen by remember { mutableStateOf(0) }
    var kText by remember { mutableStateOf(prefs.getString("k", "") ?: "") }
    var bText by remember { mutableStateOf(prefs.getString("b", "") ?: "") }
    var precision by remember { mutableIntStateOf(prefs.getInt("precision", 2).coerceIn(0, 4)) }
    var rotationsText by remember { mutableStateOf("") }
    var resultRpm by remember { mutableStateOf<Double?>(null) }
    var resultMph by remember { mutableStateOf<Double?>(null) }
    var error by remember { mutableStateOf("") }
    var history by remember { mutableStateOf(loadHistory(prefs)) }
    val t = translations[language] ?: translations.getValue("ko")
    fun saveSettings() {
        prefs.edit().putString("lang", language).putString("k", kText).putString("b", bText).putInt("precision", precision).apply()
    }
    fun calculate() {
        val count = rotationsText.trim().toIntOrNull()
        if (count == null || count < 0) { error = t[16]; return }
        val rpm = count * 6.0
        val k = kText.trim().replace(',', '.').toDoubleOrNull()
        val b = bText.trim().replace(',', '.').toDoubleOrNull()
        if (k == null || b == null || !k.isFinite() || !b.isFinite()) {
            resultRpm = rpm; resultMph = null; error = t[15]; return
        }
        val mph = rpm * k + b
        if (!mph.isFinite() || mph < 0) { error = t[16]; return }
        resultRpm = rpm; resultMph = mph; error = ""
        history = listOf(Reading(System.currentTimeMillis(), count, rpm, mph)) + history
        saveHistory(prefs, history)
    }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Navy, surface = Panel, primary = Cyan, secondary = Green,
        onBackground = White, onSurface = White
    )) {
        Column(Modifier.fillMaxSize().background(Navy).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (screen != 0) IconButton(onClick = { screen = 0 }) { Icon(Icons.Default.ArrowBack, null, tint = Cyan) }
                Column(Modifier.weight(1f)) {
                    Text("VORTEX WEATHER STATION", color = Cyan, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text(t[screen.coerceIn(0,3)], color = Muted, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(16.dp))
            when (screen) {
                0 -> Dashboard(t, history, precision, kText, bText) { screen = it }
                1 -> CalculatorScreen(t, rotationsText, { rotationsText = it }, resultRpm, resultMph, precision, error,
                    { calculate() }, { rotationsText = ""; resultRpm = null; resultMph = null; error = "" })
                2 -> HistoryScreen(t, history, precision, { index -> history = history.filterIndexed { i, _ -> i != index }; saveHistory(prefs, history) },
                    { history = emptyList(); saveHistory(prefs, history) })
                3 -> SettingsScreen(t, language, { language = it; saveSettings() }, kText, { kText = it },
                    bText, { bText = it }, precision, { precision = it; saveSettings() }, { saveSettings() },
                    { history = emptyList(); saveHistory(prefs, history) })
            }
            Spacer(Modifier.weight(1f))
            NavigationBar(containerColor = Panel) {
                NavigationBarItem(selected = screen == 0, onClick = { screen = 0 }, icon = { Icon(Icons.Default.Speed, null) }, label = { Text(t[0]) })
                NavigationBarItem(selected = screen == 1, onClick = { screen = 1 }, icon = { Icon(Icons.Default.Calculate, null) }, label = { Text(t[1]) })
                NavigationBarItem(selected = screen == 2, onClick = { screen = 2 }, icon = { Icon(Icons.Default.History, null) }, label = { Text(t[2]) })
                NavigationBarItem(selected = screen == 3, onClick = { screen = 3 }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text(t[3]) })
            }
        }
    }
}

@Composable
fun Dashboard(t: List<String>, history: List<Reading>, p: Int, k: String, b: String, navigate: (Int)->Unit) {
    val latest = history.firstOrNull()
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(t[4], color = Muted)
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(t[5], color = Muted)
                Text(latest?.let { String.format(Locale.US, "%.${p}f", it.mph) } ?: "--", color = Cyan, fontSize = 54.sp, fontWeight = FontWeight.Bold)
                Text("MPH", color = White, fontSize = 18.sp)
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(t[6], color = Muted); Text(latest?.let { String.format(Locale.US, "%.${p}f", it.rpm) } ?: "--", color = Green, fontSize = 22.sp); Text("RPM", color = Muted) }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(t[7], color = Muted); Text(latest?.let { SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(Date(it.time)) } ?: "--", color = White, fontSize = 16.sp) }
                }
            }
        }
        if (k.isBlank() || b.isBlank()) Text(t[15], color = Color(0xFFFFC66D))
        TextButton(onClick = { navigate(1) }) { Text(t[1], color = Cyan) }
        TextButton(onClick = { navigate(2) }) { Text(t[2], color = Cyan) }
        TextButton(onClick = { navigate(3) }) { Text(t[3], color = Cyan) }
    }
}

@Composable
fun CalculatorScreen(t: List<String>, rotations: String, onRotations: (String)->Unit, rpm: Double?, mph: Double?, p: Int, error: String,
                     calculate: ()->Unit, clear: ()->Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(t[8], color = Muted)
        OutlinedTextField(value = rotations, onValueChange = { onRotations(it.filter(Char::isDigit)) }, label = { Text(t[9]) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
        Text("RPM = Rotations × 6", color = Muted)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = calculate, modifier = Modifier.weight(1f)) { Text(t[10]) }
            OutlinedButton(onClick = clear, modifier = Modifier.weight(1f)) { Text(t[11]) }
        }
        if (rpm != null) ResultCard(t[13], String.format(Locale.US, "%.2f", rpm), "RPM")
        if (mph != null) ResultCard(t[5], String.format(Locale.US, "%.${p}f", mph), "MPH")
        if (error.isNotBlank()) Text(error, color = Color(0xFFFFC66D))
    }
}

@Composable
fun ResultCard(label: String, value: String, unit: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.fillMaxWidth().padding(18.dp)) {
            Text(label, color = Muted)
            Text("$value $unit", color = Cyan, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun HistoryScreen(t: List<String>, history: List<Reading>, p: Int, delete: (Int)->Unit, clearAll: ()->Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(t[2], color = White, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
            TextButton(onClick = clearAll) { Text(t[19], color = Color(0xFFFF8A80)) }
        }
        if (history.isEmpty()) Text(t[17], color = Muted)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(history) { index, item ->
                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(item.time)), color = Muted, fontSize = 12.sp)
                            Text("${item.rotations} ${t[12]} · ${String.format(Locale.US, "%.2f", item.rpm)} RPM", color = White)
                            Text("${String.format(Locale.US, "%.${p}f", item.mph)} MPH", color = Cyan, fontWeight = FontWeight.Bold)
                        }
                        TextButton(onClick = { delete(index) }) { Text(t[18], color = Color(0xFFFF8A80)) }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(t: List<String>, language: String, setLanguage: (String)->Unit, k: String, setK: (String)->Unit,
                   b: String, setB: (String)->Unit, precision: Int, setPrecision: (Int)->Unit, save: ()->Unit, clearHistory: ()->Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(t[20], color = Muted)
        var expanded by remember { mutableStateOf(false) }
        val langs = listOf("ko","en","zh","ja")
        val names = listOf(t[21],t[22],t[23],t[24])
        Box {
            OutlinedButton(onClick = { expanded = true }) { Text(names[langs.indexOf(language).coerceAtLeast(0)]) }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                langs.forEachIndexed { i, code -> DropdownMenuItem(text = { Text(names[i]) }, onClick = { setLanguage(code); expanded = false }) }
            }
        }
        Divider(color = Panel)
        Text(t[25], color = Muted)
        OutlinedTextField(value = k, onValueChange = setK, label = { Text(t[26]) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = b, onValueChange = setB, label = { Text(t[27]) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.fillMaxWidth())
        Text(t[37], color = Muted, fontSize = 12.sp)
        Text(t[38], color = Muted, fontSize = 12.sp)
        Text("${t[28]}: $precision", color = Muted)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            (0..4).forEach { n -> FilterChip(selected = precision == n, onClick = { setPrecision(n) }, label = { Text("$n") }) }
        }
        Button(onClick = save, modifier = Modifier.fillMaxWidth()) { Text(t[33]) }
        OutlinedButton(onClick = clearHistory, modifier = Modifier.fillMaxWidth()) { Text(t[36]) }
        Text("${t[29]}: ${t[30]}", color = Muted, fontSize = 12.sp)
        Text(t[31], color = Muted, fontSize = 12.sp)
    }
}

private fun loadHistory(prefs: android.content.SharedPreferences): List<Reading> {
    return try {
        val arr = JSONArray(prefs.getString("history", "[]"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Reading(o.getLong("time"), o.getInt("rotations"), o.getDouble("rpm"), o.getDouble("mph"))
        }
    } catch (_: Exception) { emptyList() }
}
private fun saveHistory(prefs: android.content.SharedPreferences, list: List<Reading>) {
    val arr = JSONArray()
    list.forEach { r -> arr.put(JSONObject().put("time", r.time).put("rotations", r.rotations).put("rpm", r.rpm).put("mph", r.mph)) }
    prefs.edit().putString("history", arr.toString()).apply()
}
